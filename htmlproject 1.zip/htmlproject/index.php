<!DOCTYPE html>
<html lang="zxx">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="author" content="dev_raj" />
    <!-- ======== Page title ============ -->
    <title>Call Analog</title>
    <meta name="description" content="Call Analog" />
    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="assets/img/solar/favicon.png" />
    <!--  Bootstrap css plugins -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <!-- template main style css file -->
    <link rel="stylesheet" href="custom.css" />
    <link rel="stylesheet" href="header.css" />
    <link rel="stylesheet" href="responsive.css" />

</head>

<body class="body-wrapper bg16 overflow-y">
    <header class="header header-1">
        <div class="main-header-wraper">
            <div class="container-fluid">
                <div class="header-flex-main">
                <a href="index.php"><img src="assets/img/image/logo.png" alt=""></a>

                    <h2 class="color-white">Welcome Back!</h2>
                </div>
            </div>
        </div>
    </header>

    <section class="main-login-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 py-2">
                    <div class="image-box">
                        <img src="assets/img/image/login.png" alt="">
                    </div>
                </div>
                <div class="col-lg-1"></div>
                <div class="col-lg-5  py-2">
                    <h4 class="color-white fpw6 mb-3">Please enter your User Id & Password</h4>
                    <div class="form-box">
                        <form action="">
                            <h4 class="color21 pb-2">Log In</h4>
                            <div class="form-group">
                                <label for="">User Id</label>
                                <input type="text" placeholder="Search for employee Id">
                            </div>
                            <div class="form-group">
                                <label for="">Password</label>
                                <input type="password" placeholder="Search for employee Id">
                            </div>
                            <div class="loginbtn">
                                <a href="">Log In</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- start main footer -->
    <?php
    // include "footer.php";
    ?>

    <!-- end footer -->

    <!--  ALl JS Plugins
    ====================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <script src="assets/js/active.js"></script>



</body>

</html>