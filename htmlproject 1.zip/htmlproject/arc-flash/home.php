<!DOCTYPE html>
<html lang="zxx">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="author" content="dev_raj" />
    <!-- ======== Page title ============ -->
    <title>ghfh</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <meta name="description" content="Call Analog" />
    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="../assets/img/solar/favicon.png" />
    <!--  Bootstrap css plugins -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" />
    <!-- template main style css file -->
    <link rel="stylesheet" href="../custom.css" />
    <link rel="stylesheet" href="../assets/css/dashboard.css" />
    <link rel="stylesheet" href="header.css" />
    <link rel="stylesheet" href="../responsive.css" />
</head>

<body class="body-wrapper bg4">
    <?php
    include "./header.php";
    ?>

    <section class="main-dashboard">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-1 col-md-1 col-sm-1 col-2">
                    <div class="main-icons-box">
                        <a href="home.php"><img src="../assets/img/image/was.png" class="icon icon1" style="background-color: #105A71;" /></a>
                        <a href="employee.php"><img src="../assets/img/image/embl.png" class="icon icon2" /></a>
                        <a href="javascript:void(0);"><img src="../assets/img/image/blad.png" class="icon icon3" /></a>
                        <a href="javascript:void(0);"><img src="../assets/img/image/Logout.png" class="icon icon3" /></a>
                    </div>
                </div>
                <div class="col-lg-10 col-md-10 col-sm-10 col-10">
                    <div class="main-dashboard-content-box">
                        <div class="row">
                            <div class="col-lg-7">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="main-users-box-arc">
                                            <div class="total-user-box">
                                                <p class="color19 fpw6 fs14 ln20">Total no. of users</p>
                                                <h3 class="color20 fpw4">234500</h3>
                                            </div>
                                        </div>
                                        <div class="graph-box-arc">
                                            <div class="content" id="tabContent2">
                                                <canvas id="arcGp1"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="main-users-box-arc">
                                            <div class="total-user-box">
                                                <p class="color19 fpw6 fs14 ln20">Total time spent (mins.) </p>
                                                <h3 class="color20 fpw4">25000</h3>
                                            </div>
                                        </div>
                                        <div class="graph-box-arc">
                                            <div class="content" id="tabContent2">
                                                <canvas id="arcGp2"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="main-users-box-arc">
                                            <div class="total-user-box">
                                                <p class="color19 fpw6 fs14 ln20">Average times spent (mins.)</p>
                                                <h3 class="color20 fpw4">64</h3>
                                            </div>
                                        </div>
                                        <div class="graph-box-arc">
                                            <div class="content" id="tabContent2">
                                                <canvas id="arcGp3"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="main-users-box-arc">
                                            <div class="total-user-box">
                                                <p class="color19 fpw6 fs14 ln20">No. of users in last 30 days</p>
                                                <h3 class="color20 fpw4">225</h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="main-users-box-arc">
                                            <div class="total-user-box">
                                                <p class="color19 fpw6 fs14 ln20">Time spent (mins.) in last 30 days</p>
                                                <h3 class="color20 fpw4">400</h3>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-6">
                            <div id="training-employee-box" class="training-employee-box">
                                <div id="tab-option" class="tab-option">
                                    <ul id="tabs" class="tabs">
                                        <li class="tab-link current" id="tab-1" data-tab="tab-1" onclick="changeTab(this)">Training Section</li>
                                        <li class="tab-link" id="tab-2" data-tab="tab-2" onclick="changeTab(this)">Employee Report</li>
                                    </ul>
                                    <div id="tab-1-content" class="tab-content current">
                                        <div class="mb20">
                                            <div class="row">
                                                <div class="col-xl-5 col-lg-6 col-md-6 col-sm-12 p-1">
                                                    <div class="main-box-tem">
                                                        <div class="total-user-box">
                                                            <p class="color19 fpw6 fs14 ln20">Total no. of participants</p>
                                                            <h3 class="color20 fpw4">19305</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xl-5 col-lg-6 col-md-6 col-sm-12 p-1">
                                                    <div class="main-box-tem">
                                                        <div class="total-user-box">
                                                            <p class="color19 fpw6 fs14 ln20">Time spent (mins.) in training</p>
                                                            <h3 class="color20 fpw4">835240</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2 p-1"></div>
                                            </div>
                                        </div>

                                    </div>
                                    <div id="tab-2-content" class="tab-content">
                                        <div class="mb20">
                                            <div class="row">
                                                <div class="col-lg-4 p-1">
                                                    <div class="main-box-tem">
                                                        <div class="total-user-box">
                                                            <p class="color19 fpw6 fs14 ln20">Training participants count</p>
                                                            <h3 class="color20 fpw4">19305</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 p-1">
                                                    <div class="main-box-tem">
                                                        <div class="total-user-box">
                                                            <p class="color19 fpw6 fs14 ln20">Compled count</p>
                                                            <h3 class="color20 fpw4">1670</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 p-1">
                                                    <div class="main-box-tem">
                                                        <div class="total-user-box">
                                                            <p class="color19 fpw6 fs14 ln20">Incompleted count</p>
                                                            <h3 class="color20 fpw4">1670</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="table-box">
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <th class="fpw6">S.no.</th>
                                                        <th class="fpw6">Name of user</th>
                                                        <th class="fpw6">Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">1. </td>
                                                        <td class="wid2" data-label="Due Date">Ralph Edwards</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/circle.png" /></span> &nbsp; Completed</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">3. </td>
                                                        <td class="wid2" data-label="Due Date">Cameron Williamson</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/circle.png" /></span> &nbsp; Completed</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">3. </td>
                                                        <td class="wid2" data-label="Due Date">Bessie Cooper</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/red-circle.png" /></span> &nbsp; Incomplete</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">4. </td>
                                                        <td class="wid2" data-label="Due Date">Ronald Richards</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/circle.png" /></span> &nbsp; Completed</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">5. </td>
                                                        <td class="wid2" data-label="Due Date">Darrell Steward</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/circle.png" /></span> &nbsp; Completed</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">6. </td>
                                                        <td class="wid2" data-label="Due Date">Cameron Williamson</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/circle.png" /></span> &nbsp; Completed</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">7. </td>
                                                        <td class="wid2" data-label="Due Date">Bessie Cooper</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/red-circle.png" /></span> &nbsp; Incomplete</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">8. </td>
                                                        <td class="wid2" data-label="Due Date">Ronald Richards</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/circle.png" /></span> &nbsp; Completed</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="tab-parent">
                                <div class="tab-container">
                                    <div class="tabs">
                                        <button class="tab-btn active" data-tab="tab1">Assessment Section</button>
                                        <button class="tab-btn" data-tab="tab2">Employee Report</button>
                                    </div>
                                    <div class="tab-content active" id="tab1">
                                        <div class="mb20">
                                            <div class="row">
                                                <div class="col-xl-5 col-lg-6 col-md-6 col-sm-12 p-1">
                                                    <div class="main-box-assessment">
                                                        <div class="total-user-box">
                                                            <p class="color19 fpw6 fs14 ln20">Total no. of participants</p>
                                                            <h3 class="color20 fpw4">19305</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xl-5 col-lg-6 col-md-6 col-sm-12 p-1">
                                                    <div class="main-box-assessment">
                                                        <div class="total-user-box">
                                                            <p class="color19 fpw6 fs14 ln20">Total no. of participants</p>
                                                            <h3 class="color20 fpw4">19305</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2 p-1"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-content" id="tab2">
                                        <div class="mb20">
                                            <div class="row">
                                                <div class="col-lg-4 p-1">
                                                    <div class="main-box-tem">
                                                        <div class="total-user-box">
                                                            <p class="color19 fpw6 fs14 ln20">Training participants count</p>
                                                            <h3 class="color20 fpw4">19305</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 p-1">
                                                    <div class="main-box-tem">
                                                        <div class="total-user-box">
                                                            <p class="color19 fpw6 fs14 ln20">Compled count</p>
                                                            <h3 class="color20 fpw4">1670</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 p-1">
                                                    <div class="main-box-tem">
                                                        <div class="total-user-box">
                                                            <p class="color19 fpw6 fs14 ln20">Incompleted count</p>
                                                            <h3 class="color20 fpw4">1670</h3>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="table-box">
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <th class="fpw6">S.no.</th>
                                                        <th class="fpw6">Name of user</th>
                                                        <th class="fpw6">Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">1. </td>
                                                        <td class="wid2" data-label="Due Date">Ralph Edwards</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/circle.png" /></span> &nbsp; Pass</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">3. </td>
                                                        <td class="wid2" data-label="Due Date">Cameron Williamson</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/circle.png" /></span> &nbsp; Pass</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">3. </td>
                                                        <td class="wid2" data-label="Due Date">Bessie Cooper</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/red-circle.png" /></span> &nbsp; Fail</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">4. </td>
                                                        <td class="wid2" data-label="Due Date">Ronald Richards</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/circle.png" /></span> &nbsp; Pass</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">5. </td>
                                                        <td class="wid2" data-label="Due Date">Darrell Steward</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/circle.png" /></span> &nbsp; Pass</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">6. </td>
                                                        <td class="wid2" data-label="Due Date">Cameron Williamson</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/circle.png" /></span> &nbsp; Pass</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">7. </td>
                                                        <td class="wid2" data-label="Due Date">Bessie Cooper</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/red-circle.png" /></span> &nbsp; Fail</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="wid1" data-label="Account">8. </td>
                                                        <td class="wid2" data-label="Due Date">Ronald Richards</td>
                                                        <td class="wid3" data-label="Amount"><span><img src="../assets/img/image/circle.png" /></span> &nbsp; Pass</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-1 col-sm-12"></div>
            </div>
        </div>
    </section>

    <?php
    include "footer.php";
    ?>


    <!--  ALl JS Plugins
    ====================================== -->
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>

    <script src="../assets/js/active.js"></script>
    <script src="./index.js"></script>

    <script>
        // arcgp1 

        function renderArcGp1Chart() {
            const arcGp1Data = {
                labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"],
                datasets: [{
                    label: "",
                    data: [50, 60, 70, 80, 90, 100, 110],
                    fill: false,
                    borderColor: "#004B63",
                    tension: 0.1,
                }],
            };

            const arcGp1Config = {
                type: "line",
                data: arcGp1Data,
                options: {
                    scales: {
                        x: {
                            ticks: {
                                color: "#3C5D68",
                                font: {
                                    size: 12,
                                    weight: 400,
                                },
                            },
                        },
                        y: {
                            ticks: {
                                color: "#3C5D68",
                                font: {
                                    size: 12,
                                    weight: 600,
                                },
                            },
                        },
                    },
                    elements: {
                        line: {
                            borderWidth: 2,
                        },
                        point: {
                            radius: 2,
                        },
                    },
                    plugins: {
                        legend: {
                            display: false,
                        },
                        tooltip: {
                            enabled: false,
                        },
                    },
                },
            };

            // Initialize the chart
            const arcGp1ChartInstance = new Chart(
                document.getElementById("arcGp1").getContext("2d"),
                arcGp1Config
            );
        }

        // Call the function to render the chart when the document is ready
        document.addEventListener("DOMContentLoaded", renderArcGp1Chart);

        // arcgp2 
        function renderArcGp2Chart() {
            const arcGp2Data = {
                labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"],
                datasets: [{
                    label: "",
                    data: [70, 80, 90, 100, 110, 120, 130],
                    fill: false,
                    borderColor: "#004B63",
                    tension: 0.1,
                }],
            };

            const arcGp2Config = {
                type: "line",
                data: arcGp2Data,
                options: {
                    scales: {
                        x: {
                            ticks: {
                                color: "#3C5D68",
                                font: {
                                    size: 12,
                                    weight: 400,
                                },
                            },
                        },
                        y: {
                            ticks: {
                                color: "#3C5D68",
                                font: {
                                    size: 12,
                                    weight: 600,
                                },
                            },
                        },
                    },
                    elements: {
                        line: {
                            borderWidth: 2,
                        },
                        point: {
                            radius: 2,
                        },
                    },
                    plugins: {
                        legend: {
                            display: false,
                        },
                        tooltip: {
                            enabled: false,
                        },
                    },
                },
            };

            // Initialize the chart
            const arcGp2ChartInstance = new Chart(
                document.getElementById("arcGp2").getContext("2d"),
                arcGp2Config
            );
        }

        // Call the function to render the chart when the document is ready
        document.addEventListener("DOMContentLoaded", renderArcGp2Chart);


        // arcgp 3 
        function renderArcGp3Chart() {
            const arcGp3Data = {
                labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"],
                datasets: [{
                    label: "",
                    data: [80, 90, 100, 110, 120, 130, 140],
                    fill: false,
                    borderColor: "#004B63",
                    tension: 0.1,
                }],
            };

            const arcGp3Config = {
                type: "line",
                data: arcGp3Data,
                options: {
                    scales: {
                        x: {
                            ticks: {
                                color: "#3C5D68",
                                font: {
                                    size: 12,
                                    weight: 400,
                                },
                            },
                        },
                        y: {
                            ticks: {
                                color: "#3C5D68",
                                font: {
                                    size: 12,
                                    weight: 600,
                                },
                            },
                        },
                    },
                    elements: {
                        line: {
                            borderWidth: 2,
                        },
                        point: {
                            radius: 2,
                        },
                    },
                    plugins: {
                        legend: {
                            display: false,
                        },
                        tooltip: {
                            enabled: false,
                        },
                    },
                },
            };

            // Initialize the chart
            const arcGp3ChartInstance = new Chart(
                document.getElementById("arcGp3").getContext("2d"),
                arcGp3Config
            );
        }

        // Call the function to render the chart when the document is ready
        document.addEventListener("DOMContentLoaded", renderArcGp3Chart);
    </script>




</body>

</html>