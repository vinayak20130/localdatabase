<style>
    .header-flex-main {
        display: flex;
        justify-content: space-between;
    }

    .header-flex-main span a {
        border: 1px solid #C5C5C5;
        background-color: #ffffff;
        border-radius: 4px;
        padding: 8px 12px;
        font-size: 28px;
        font-weight: 400;
        line-height: 40px;
        color: #004B63;
    }
</style>

<!-- header end -->
<header class="header header-1">
    <div class="main-header-wraper">
        <div class="container-fluid">
            <div class="header-flex-main">
            <a href="index.php"><img src="../assets/img/image/logo.png" alt=""></a>

                <h2 class="color-white">Hello, Admin A!, Welcome to &nbsp;<span><a href=""> Winch Assembly</a></span></h2>
            </div>
        </div>
    </div>
</header>