
<footer>
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-lg-4 col-sm-12">
                    <div class="find-address-box">
                        <p><span><img src="../assets/img/image/location.png" /></span> &nbsp; Find us at</p>
                        <p>428 Suncity Success Tower, Sector 65 Gurugram IN</p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-12">
                    <div class="terms">
                        <a href="">Terms & Contions</a>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-12">
                    <div class="contact-details">
                        <p><span><img src="../assets/img/image/call.png" /></span> &nbsp; In case of help, reach us at</p>
                        <p><a href="tel:987656765">+91 987656765</a></p>
                        <p><a href="mailto:example-help@innovate-labs.com">example-help@innovate-labs.com</a></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
